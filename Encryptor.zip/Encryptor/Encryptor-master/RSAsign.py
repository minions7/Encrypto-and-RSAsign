# coding=utf-8

from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Hash import MD5
from Crypto import Random


# 伪随机数生成器
random_generator = Random.new().read
# 生成2048比特秘钥对(pk, sk)
rsa = RSA.generate(2048, random_generator)
private_pem = rsa.exportKey()
with open('master-privatekey.pem', 'wb') as f:
    f.write(private_pem)
public_pem = rsa.publickey().exportKey()
with open('master-publickey.pem', 'wb') as f:
    f.write(public_pem)

message='124314'
# 对消息进行签名
h = MD5.new(message.encode('utf-8'))
private_key = RSA.importKey(open('master-privatekey.pem').read())
signer = PKCS1_v1_5.new(private_key)
signature = signer.sign(h)
print(signature)
# 对消息进行签名验证
h = MD5.new(message.encode('utf-8'))
public_key = RSA.importKey(open('master-publickey.pem', 'r').read())
verifier = PKCS1_v1_5.new(public_key)
if verifier.verify(h, signature):
    print('signature is valued')
else:
    print('signature is unvalued')
