# tkinter 图形开发界面的其中一个库
from tkinter import *
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Hash import MD5
from Crypto import Random
import des
import Caesar
import rc4
import gost


class Application(Frame):
    def __init__(self, languages=Listbox(), master=None):
        Frame.__init__(self, master)
        self.init()
        self.settings()
        self.show()

    # 定义函数，label标签，button按钮，entry输入，command命令，对应的button对应相应的Show函数去执行
    def InputWidgets(self):
        self.hint = Label(self, text='输入要加密的明文:')
        self.Input = Entry(self)
        self.hintRc4 = Label(self, text='输入key:')
        self.Gosthint = Label(self, text='Gost 的明文和key必须是数字')
        self.Rc4Input = Entry(self)
        self.CaserButton = Button(self, text='Caesar', command=self.CaesarShow)
        self.DesButton = Button(self, text='Des', command=self.DesShow)
        self.DeDesButton = Button(self, text='Decode Des', command=self.DeDesShow)
        self.Rc4Button = Button(self, text='RC4', command=self.Rc4Show)
        self.DeRc4Button = Button(self, text='Decode RC4', command=self.DeRc4Show)
        self.GostButton = Button(self, text='Gost', command=self.GostShow)
        self.DeGostButton = Button(self, text='Decode Gost', command=self.DeGostShow)
        self.RSAsignButton = Button(self, text='RSA sign', command=self.RSAsignShow)

    def OutputWidgets(self):
        self.OutputCaesar = Label(self, textvariable=self.CaesarText)
        self.OutputDes = Label(self, textvariable=self.DesText)
        self.OutputDeDes = Label(self, textvariable=self.DeDesText)
        self.OutputRc4 = Label(self, textvariable=self.Rc4Text)
        self.OutputDeRc4 = Label(self, textvariable=self.DeRc4Text)
        self.OutputGost = Label(self, textvariable=self.GostText)
        self.OutputDeGost = Label(self, textvariable=self.DeGostText)
        self.OutputRSAsign = Label(self, textvariable=self.RSAsignText)

    # 产生的结果是经过凯撒密码加密的
    def CaesarShow(self):
        plaintext = self.Input.get() or ''
        Casercipher = Caesar.doCaesar(plaintext)
        self.CaesarText.set(Casercipher)

    # 产生的结果是经过DES加密的
    def DesShow(self):
        plaintext = self.Input.get() or ''
        k = des.des(b"DESCRYPT", des.CBC, b"\0\0\0\0\0\0\0\0", pad=None, padmode=des.PAD_PKCS5)
        d = k.encrypt(plaintext)
        Encrypted = str(d).replace('b', '', 1)
        self.DesDecrypted = str(k.decrypt(d)).replace('b', '', 1)
        DesCipher = Encrypted
        self.DesText.set(DesCipher)

    # 产生的结果是经过DES解密的
    def DeDesShow(self):
        if self.DesDecrypted == 0:
            self.DeDesText.set('Des Encryption First')
        else:
            self.DeDesText.set(self.DesDecrypted)

    # 产生的结果是经过RC4加密的
    def Rc4Show(self):
        Key = self.Rc4Input.get() or ''
        plaintext = self.Input.get() or ''

        key = [ord(c) for c in Key]

        keystream = rc4.RC4(key)
        cipher = ''
        import sys
        for c in plaintext:
            k = "%02X" % (ord(c) ^ keystream.__next__())
            cipher += k
        self.Rc4Decrypted = plaintext
        self.Rc4Text.set(cipher)

    # 产生的结果是经过RC4解密的
    def DeRc4Show(self):
        if self.Rc4Decrypted == 0:
            self.DeRc4Text.set('RC4 Encryption First')
        else:
            self.DeRc4Text.set(self.Rc4Decrypted)

    # 产生的结果是经过GOST加密的
    def GostShow(self):
        Key = int(self.Rc4Input.get() or '')
        text = int(self.Input.get() or '')

        my_GOST = gost.GOST()
        my_GOST.set_key(Key)

        num = 1000

        for i in range(num):
            text = my_GOST.encrypt(text)
        print('%x' % text)
        cipher = text
        self.GostText.set(cipher)
        for i in range(num):
            text = my_GOST.decrypt(text)
        print('%x' % text)
        self.GostDecrypted = text

    # 产生的结果是经过GOST解密的
    def DeGostShow(self):
        if self.GostDecrypted == 0:
            self.DeGostText.set('Gost Encryption First')
        else:
            self.DeGostText.set(self.GostDecrypted)

    def RSAsignShow(self):
        message = self.Input.get() or ''
        RSAsigncipher = self.RSAsign(message)
        self.RSAsignText.set(RSAsigncipher)

    # 初始化 提前设置为***
    def init(self):
        self.DesDecrypted = 0
        self.CaesarText = StringVar()
        self.CaesarText.set('***')
        self.DesText = StringVar()
        self.DesText.set('***')
        self.DeDesText = StringVar()
        self.DeDesText.set('***')
        self.Rc4Text = StringVar()
        self.Rc4Text.set('***')
        self.DeRc4Text = StringVar()
        self.DeRc4Text.set('***')
        self.GostText = StringVar()
        self.GostText.set('***')
        self.DeGostText = StringVar()
        self.DeGostText.set('***')
        self.RSAsignText = StringVar()
        self.RSAsignText.set('***')
        self.InputWidgets()
        self.OutputWidgets()

    def settings(self):
        self.master.title('PassWord')
        # geometry用于设置窗口尺寸
        self.master.geometry()

    # 定义图形化界面的排序
    def show(self):
        self.pack()
        self.hint.pack()
        self.Input.pack()
        self.CaserButton.pack()
        self.OutputCaesar.pack()
        self.DesButton.pack()
        self.OutputDes.pack()
        self.DeDesButton.pack()
        self.OutputDeDes.pack()
        self.hintRc4.pack()
        self.Rc4Input.pack()
        self.Rc4Button.pack()
        self.OutputRc4.pack()
        self.DeRc4Button.pack()
        self.OutputDeRc4.pack()
        self.Gosthint.pack()
        self.GostButton.pack()
        self.OutputGost.pack()
        self.DeGostButton.pack()
        self.OutputDeGost.pack()
        self.RSAsignButton.pack()
        self.OutputRSAsign.pack()

    def RSAsign(self, message):

        # 伪随机数生成器
        random_generator = Random.new().read

        # 生成2048比特秘钥对(pk, sk)
        rsa = RSA.generate(2048, random_generator)
        private_pem = rsa.exportKey()
        with open('master-privatekey.pem', 'wb') as f:
            f.write(private_pem)
        public_pem = rsa.publickey().exportKey()
        with open('master-publickey.pem', 'wb') as f:
            f.write(public_pem)

        # 对消息进行签名
        h = MD5.new(message.encode('utf-8'))
        private_key = RSA.importKey(open('master-privatekey.pem').read())
        signer = PKCS1_v1_5.new(private_key)
        signature = signer.sign(h)
        print(signature)
        # 对消息进行签名验证
        h = MD5.new(message.encode('utf-8'))
        public_key = RSA.importKey(open('master-publickey.pem', 'r').read())
        verifier = PKCS1_v1_5.new(public_key)
        if verifier.verify(h, signature):
            print(message)
            # return 'signature is value'
            return message, 'signature is value'
        else:
            return 'Invalid Signature'


app = Application()
# 设置窗口标题:

# 主消息循环:
app.mainloop()
