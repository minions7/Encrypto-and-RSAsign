# 传统加密技术，凯撒密码，代换技术，置换技术。
# def用来定义函数，doCaesar,plaintext是纯文本的意思。
def doCaesar(plaintext):
    cipher = ''
    # 循环进行移位代换
    for i in plaintext:
        # ord（i）是取i所在的字符的对应的ASCII码
        asc = ord(i)
        # 所有的字符向前移动三位
        asc = asc + 3
        # 如果下面的成立，说明asc对应的字符串是在0-9之间，则转换出来的密文也是0-9的数字。
        if ord('0') + 3 <= asc <= ord('9') + 3:
            # m是asc和ord('9')的余数，余数一定是0-9之间
            m = asc % ord('9')
            if m <= 3 and m != 0:
                asc = ord('0') + m - 1
            # chr(asc)是将ASCII转换回对应的字符串。
            cipher = cipher + chr(asc)
        # 如果下面成立，说明asc对应的字符串是在A-Z之间，转换出来的密文也是A-Z的字母。
        elif ord('A') + 3 <= asc <= ord('Z') + 3:
            # 做余数得到m
            m = asc % ord('Z')
            if m <= 3 and m != 0:
                asc = ord('A') + m - 1
            # chr(asc)是将ASCII转换回对应的字符串。
            cipher = cipher + chr(asc)
        # 如果下面成立，说明asc对应的字符串是在a-z之间，转换出来的密文也是a-z的字母。
        elif ord('a') + 3 <= asc <= ord('z') + 3:
            # 做余数得到m
            m = asc % ord('z')
            if m <= 3 and m != 0:
                asc = ord('a') + m - 1
            # chr(asc)是将ASCII转换回对应的字符串。
            cipher = cipher + chr(asc)
        # 如果都不是上述三种情况，cipher直接是i
        else:
            cipher = cipher + i
    return cipher
