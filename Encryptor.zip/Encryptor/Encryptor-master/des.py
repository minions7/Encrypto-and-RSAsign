# -*- coding:utf-8 -*-
# 对称加密des算法，加密和解密使用相同的密钥。
# DES3为DES向AES过渡的算法，它使用三条56位的密钥对数据进行三次加密，为了兼容普通的DES，DES3采用加密解密加密的方式。

# _pythonMajorVersion 用于处理python2和python3的差异
import sys

from numpy import unicode

_pythonMajorVersion = sys.version_info[0]

# ECB电码本加密模式，是分组密码的一种最基本的模式，在该模式下，该信息被分解成大小合适的分组，之后分别进行加解密。
# CBC密码分组链接模式，每个明文块先与前一个密文快进行异或，然后在进行加密。
ECB = 0
CBC = 1

# 填充模式padding PKCS5填充可以将数据填充为8的倍数。
PAD_NORMAL = 1
PAD_PKCS5 = 2


# des和三重des共享的基类。IV是初始值，pad是填充，padmode是填充类型
class _baseDes(object):
    def __init__(self, mode=ECB, IV=None, pad=None, padmode=PAD_NORMAL):
        if IV:
            IV = self._guardAgainstUnicode(IV)
        if pad:
            pad = self._guardAgainstUnicode(pad)
        self.block_size = 8
        # 参数的健全性检查
        if pad and padmode == PAD_PKCS5:
            # 引发指定类型的异常后，附带异常的描述信息。
            raise ValueError("Cannot use a pad character with PAD_PKCS5")
        if IV and len(IV) != self.block_size:
            # 引发指定类型的异常后，附带异常的描述信息。
            raise ValueError("Invalid Initial Value (IV), must be a multiple of " + str(self.block_size) + " bytes")

        # 设置传入的变量
        self._mode = mode
        self._iv = IV
        self._padding = pad
        self._padmode = padmode

    def getKey(self):
        # getKey() -> bytes 获取密钥
        return self.__key

    def setKey(self, key):
        # 将为此对象设置加密密钥
        key = self._guardAgainstUnicode(key)
        self.__key = key

    def getMode(self):
        # getMode() -> pyDes.ECB or pyDes.CBC 获取加密模式
        return self._mode

    def setMode(self, mode):
        # 设置加密模式的类型，ECB或者CBC。
        self._mode = mode

    def getPadding(self):
        # getPadding() -> bytes of length 1. 填充角色.
        return self._padding

    def setPadding(self, pad):
        # setPadding() -> bytes of length 1. 填充角色.
        if pad is not None:
            pad = self._guardAgainstUnicode(pad)
        self._padding = pad

    def getPadMode(self):
        # getPadMode() -> pyDes.PAD_NORMAL or pyDes.PAD_PKCS5 填充模式
        return self._padmode

    def setPadMode(self, mode):
        # 设置填充模式的类型, pyDes.PAD_NORMAL or pyDes.PAD_PKCS5。
        self._padmode = mode

    def getIV(self):
        # getIV() -> bytes
        return self._iv

    def setIV(self, IV):
        # 将设置初始值，与CBC模式一起使用
        if not IV or len(IV) != self.block_size:
            raise ValueError("Invalid Initial Value (IV), must be a multiple of " + str(self.block_size) + " bytes")
        IV = self._guardAgainstUnicode(IV)
        self._iv = IV

    def _padData(self, data, pad, padmode):
        # 填充数据取决于模式
        if padmode is None:
            # 获取默认填充模式
            padmode = self.getPadMode()
        if pad and padmode == PAD_PKCS5:
            raise ValueError("Cannot use a pad character with PAD_PKCS5")

        if padmode == PAD_NORMAL:
            # 看数据的长度能不能整除块的大小，如果可以，那么就不用进行填充。
            if len(data) % self.block_size == 0:
                # 不需要填充.
                return data

            if not pad:
                # 获取默认填充.
                pad = self.getPadding()
            if not pad:
                raise ValueError("Data must be a multiple of " + str(
                    self.block_size) + " bytes in length. Use padmode=PAD_PKCS5 or set the pad character.")
            data += (self.block_size - (len(data) % self.block_size)) * pad

        # PKCS5可以填充8的倍数，所以填充长度就是8-数据的长度和块的大小的余
        elif padmode == PAD_PKCS5:
            pad_len = 8 - (len(data) % self.block_size)
            if _pythonMajorVersion < 3:
                data += pad_len * chr(pad_len)
            else:
                data += bytes([pad_len] * pad_len)
        return data

    def _unpadData(self, data, pad, padmode):
        # 根据模式取消填充数据.
        if not data:
            return data
        if pad and padmode == PAD_PKCS5:
            raise ValueError("Cannot use a pad character with PAD_PKCS5")
        if padmode is None:
            # 获取默认填充模式.
            padmode = self.getPadMode()

        if padmode == PAD_NORMAL:
            if not pad:
                # 获取默认填充模式.
                pad = self.getPadding()
            if pad:
                data = data[:-self.block_size] + \
                       data[-self.block_size:].rstrip(pad)

        elif padmode == PAD_PKCS5:
            if _pythonMajorVersion < 3:
                pad_len = ord(data[-1])
            else:
                # data[-1]是从data的最后一个开始
                pad_len = data[-1]
            data = data[:-pad_len]

        return data

    def _guardAgainstUnicode(self, data):
        # 仅接受字节字符串或ascii和unicode值
        # 否则无法将数据正确解码为字节.
        if _pythonMajorVersion < 3:
            # 判断一个对象是否是一个已知的类型
            if isinstance(data, unicode):
                raise ValueError("pyDes can only work with bytes, not Unicode strings.")
        else:
            if isinstance(data, str):
                # 仅接受ascii和unicode值.
                try:
                    return data.encode('ascii')
                except UnicodeEncodeError:
                    pass
                raise ValueError("pyDes can only work with encoded strings, not Unicode.")
        return data


class des(_baseDes):
    # DES的置换和转换表
    __pc1 = [56, 48, 40, 32, 24, 16, 8,
             0, 57, 49, 41, 33, 25, 17,
             9, 1, 58, 50, 42, 34, 26,
             18, 10, 2, 59, 51, 43, 35,
             62, 54, 46, 38, 30, 22, 14,
             6, 61, 53, 45, 37, 29, 21,
             13, 5, 60, 52, 44, 36, 28,
             20, 12, 4, 27, 19, 11, 3
             ]

    # pc1的左旋转次数
    __left_rotations = [
        1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1
    ]

    # 置换选择键 （表二）
    __pc2 = [
        13, 16, 10, 23, 0, 4,
        2, 27, 14, 5, 20, 9,
        22, 18, 11, 3, 25, 7,
        15, 6, 26, 19, 12, 1,
        40, 51, 30, 36, 46, 54,
        29, 39, 50, 44, 32, 47,
        43, 48, 38, 55, 33, 52,
        45, 41, 49, 35, 28, 31
    ]

    # 初始置换ip
    __ip = [57, 49, 41, 33, 25, 17, 9, 1,
            59, 51, 43, 35, 27, 19, 11, 3,
            61, 53, 45, 37, 29, 21, 13, 5,
            63, 55, 47, 39, 31, 23, 15, 7,
            56, 48, 40, 32, 24, 16, 8, 0,
            58, 50, 42, 34, 26, 18, 10, 2,
            60, 52, 44, 36, 28, 20, 12, 4,
            62, 54, 46, 38, 30, 22, 14, 6
            ]

    # 用于将32位块转换为48位的扩展表
    __expansion_table = [
        31, 0, 1, 2, 3, 4,
        3, 4, 5, 6, 7, 8,
        7, 8, 9, 10, 11, 12,
        11, 12, 13, 14, 15, 16,
        15, 16, 17, 18, 19, 20,
        19, 20, 21, 22, 23, 24,
        23, 24, 25, 26, 27, 28,
        27, 28, 29, 30, 31, 0
    ]

    # S盒
    __sbox = [
        # S1
        [14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7,
         0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8,
         4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0,
         15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13],

        # S2
        [15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10,
         3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5,
         0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15,
         13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9],

        # S3
        [10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8,
         13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1,
         13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7,
         1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12],

        # S4
        [7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15,
         13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9,
         10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4,
         3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14],

        # S5
        [2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9,
         14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6,
         4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14,
         11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3],

        # S6
        [12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11,
         10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8,
         9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6,
         4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13],

        # S7
        [4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1,
         13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6,
         1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2,
         6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12],

        # S8
        [13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7,
         1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2,
         7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8,
         2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11],
    ]
    # 八个s盒输出每个四位，总共32位，这32位作为p盒置换的输入块
    # S盒输出上使用的32位置换函数p
    __p = [
        15, 6, 19, 20, 28, 11,
        27, 16, 0, 14, 22, 25,
        4, 17, 30, 9, 1, 7,
        23, 13, 31, 26, 2, 8,
        18, 12, 29, 5, 21, 10,
        3, 24
    ]

    # 最终置换ip
    __fp = [
        39, 7, 47, 15, 55, 23, 63, 31,
        38, 6, 46, 14, 54, 22, 62, 30,
        37, 5, 45, 13, 53, 21, 61, 29,
        36, 4, 44, 12, 52, 20, 60, 28,
        35, 3, 43, 11, 51, 19, 59, 27,
        34, 2, 42, 10, 50, 18, 58, 26,
        33, 1, 41, 9, 49, 17, 57, 25,
        32, 0, 40, 8, 48, 16, 56, 24
    ]

    # 正在进行的加密类型
    ENCRYPT = 0x00
    DECRYPT = 0x01

    # 初始化，IV是初始值
    def __init__(self, key, mode=ECB, IV=None, pad=None, padmode=PAD_NORMAL):
        # 参数的健全性检查
        if len(key) != 8:
            raise ValueError("Invalid DES key size. Key must be exactly 8 bytes long.")
        _baseDes.__init__(self, mode, IV, pad, padmode)
        self.key_size = 8

        self.L = []
        self.R = []
        self.Kn = [[0] * 48] * 16  # 16个48-bit keys (K1 - K16)
        self.final = []

        self.setKey(key)

    def setKey(self, key):
        # 将为此对象设置加密密钥，必须为8个字节.
        _baseDes.setKey(self, key)
        self.__create_sub_keys()

    def __String_to_BitList(self, data):
        # 将字符串数据转换为（1，0）的列表
        if _pythonMajorVersion < 3:
            # 将字符串转换为整数，python3使用字节
            # 是一个已经具有此行为的类.
            data = [ord(c) for c in data]
        l = len(data) * 8
        result = [0] * l
        pos = 0
        for ch in data:
            i = 7
            while i >= 0:
                if ch & (1 << i) != 0:
                    result[pos] = 1
                else:
                    result[pos] = 0
                pos += 1
                i -= 1

        return result

    def __BitList_to_String(self, data):
        # 将位列表的数据转换成字符串
        result = []
        pos = 0
        c = 0
        while pos < len(data):
            c += data[pos] << (7 - (pos % 8))
            if (pos % 8) == 7:
                # append可以在列表末尾处添加新对象
                result.append(c)
                # c清零
                c = 0
            pos += 1

        if _pythonMajorVersion < 3:
            return ''.join([chr(c) for c in result])
        else:
            return bytes(result)

    # 置换函数
    def __permutate(self, table, block):
        # 用指定的表置换此块
        return list(map(lambda x: block[x], table))

    # 转换密钥，以便为数据处理做准备
    # 创建16个子密钥 K[1]-K[16]
    def __create_sub_keys(self):
        # 从给定的密钥创建16个子密钥K[1]-K[16]
        key = self.__permutate(des.__pc1, self.__String_to_BitList(self.getKey()))
        i = 0
        # 分成左和右两个部分
        self.L = key[:28]
        self.R = key[28:]
        while i < 16:
            j = 0
            # 执行循环左移
            while j < des.__left_rotations[i]:
                self.L.append(self.L[0])
                del self.L[0]
                # append可以在列表末尾处添加新对象
                self.R.append(self.R[0])
                del self.R[0]

                j += 1

            # 通过pc2置换创建16个子密钥之一
            self.Kn[i] = self.__permutate(des.__pc2, self.L + self.R)

            i += 1

    # 加密算法的主要部分，数字处理器
    def __des_crypt(self, block, crypt_type):
        # 通过des位操作加密数据块
        block = self.__permutate(des.__ip, block)
        self.L = block[:32]
        self.R = block[32:]

        # 加密从Kn[1]开始到Kn[16]
        if crypt_type == des.ENCRYPT:
            iteration = 0
            iteration_adjustment = 1
        # 解密从Kn[16]开始到Kn[1]
        else:
            iteration = 15
            iteration_adjustment = -1

        i = 0
        while i < 16:
            # 复制R[i-1]，这将在以后成为L[i]
            tempR = self.R[:]

            # 置换R[i-1]以开始创建R[i]
            self.R = self.__permutate(des.__expansion_table, self.R)

            # 异或R[i-1]与K[i]，在此处创建B[1]到B[8]
            self.R = list(map(lambda x, y: x ^ y, self.R, self.Kn[iteration]))
            B = [self.R[:6], self.R[6:12], self.R[12:18], self.R[18:24], self.R[24:30], self.R[30:36], self.R[36:42],
                 self.R[42:]]

            # 使用S盒将B[1]置换到B[8]
            j = 0
            Bn = [0] * 32
            pos = 0
            while j < 8:
                # 计算偏移量
                m = (B[j][0] << 1) + B[j][5]
                n = (B[j][1] << 3) + (B[j][2] << 2) + (B[j][3] << 1) + B[j][4]

                # 查找置换值
                v = des.__sbox[j][(m << 4) + n]

                # 将值转换为位，将其添加到结果：Bn
                Bn[pos] = (v & 8) >> 3
                Bn[pos + 1] = (v & 4) >> 2
                Bn[pos + 2] = (v & 2) >> 1
                Bn[pos + 3] = v & 1

                pos += 4
                j += 1

            # 将B[1]置换为B[8]
            self.R = self.__permutate(des.__p, Bn)

            # 带L[i-1]的异或
            self.R = list(map(lambda x, y: x ^ y, self.R, self.L))

            # L[i] 变为 R[i - 1]
            self.L = tempR

            i += 1
            iteration += iteration_adjustment

        # R[16]L[16]的最终置换
        self.final = self.__permutate(des.__fp, self.R + self.L)
        return self.final

    # 要加密/解密的数据
    def crypt(self, data, crypt_type):
        # 在块中加密数据，通过des_Crypt（）运行数据

        # 错误检查数据
        if not data:
            return ''
        if len(data) % self.block_size != 0:
            if crypt_type == des.DECRYPT:  # 解密必须在为8个字节的块中。
                raise ValueError(
                    "Invalid data length, data must be a multiple of " + str(self.block_size) + " bytes\n.")
            if not self.getPadding():
                raise ValueError("Invalid data length, data must be a multiple of " + str(
                    self.block_size) + " bytes\n. Try setting the optional padding character")
            else:
                data += (self.block_size - (len(data) % self.block_size)) * self.getPadding()
        # print "Len of data: %f" % (len(data) / self.block_size)

        if self.getMode() == CBC:
            if self.getIV():
                iv = self.__String_to_BitList(self.getIV())
            else:
                raise ValueError("For CBC mode, you must supply the Initial Value (IV) for ciphering")

        # 将数据拆分为块，分别对每个块进行加密
        i = 0
        dict = {}
        result = []

        while i < len(data):
            # 分的块要是8的倍数
            block = self.__String_to_BitList(data[i:i + 8])

            # 使用CBC模式时带初始值IV的异或
            if self.getMode() == CBC:
                if crypt_type == des.ENCRYPT:
                    block = list(map(lambda x, y: x ^ y, block, iv))

                processed_block = self.__des_crypt(block, crypt_type)

                if crypt_type == des.DECRYPT:
                    processed_block = list(map(lambda x, y: x ^ y, processed_block, iv))
                    iv = block
                else:
                    iv = processed_block
            else:
                processed_block = self.__des_crypt(block, crypt_type)

            result.append(self.__BitList_to_String(processed_block))

            i += 8

        # 返回完全加密的字符串
        if _pythonMajorVersion < 3:
            return ''.join(result)
        else:
            return bytes.fromhex('').join(result)

    # 定义加密函数
    def encrypt(self, data, pad=None, padmode=None):

        data = self._guardAgainstUnicode(data)
        if pad is not None:
            pad = self._guardAgainstUnicode(pad)
        data = self._padData(data, pad, padmode)
        return self.crypt(data, des.ENCRYPT)

    # 定义解密函数
    def decrypt(self, data, pad=None, padmode=None):

        data = self._guardAgainstUnicode(data)
        if pad is not None:
            pad = self._guardAgainstUnicode(pad)
        data = self.crypt(data, des.DECRYPT)
        return self._unpadData(data, pad, padmode)


# 三重DES
class triple_des(_baseDes):
    # 定义初始化函数
    def __init__(self, key, mode=ECB, IV=None, pad=None, padmode=PAD_NORMAL):
        _baseDes.__init__(self, mode, IV, pad, padmode)
        self.setKey(key)

    def setKey(self, key):
        # 将为此对象设置加密密钥。16或24字节长。
        self.key_size = 24  # 使用DES-EDE3模式
        if len(key) != self.key_size:
            if len(key) == 16:  # 使用DES-EDE2模式
                self.key_size = 16
            else:
                raise ValueError("Invalid triple DES key size. Key must be either 16 or 24 bytes long")
        if self.getMode() == CBC:
            if not self.getIV():
                # 使用密钥最开始的8个字节
                self._iv = key[:self.block_size]
            if len(self.getIV()) != self.block_size:
                raise ValueError("Invalid IV, must be 8 bytes in length")
        self.__key1 = des(key[:8], self._mode, self._iv,
                          self._padding, self._padmode)
        self.__key2 = des(key[8:16], self._mode, self._iv,
                          self._padding, self._padmode)
        if self.key_size == 16:
            self.__key3 = self.__key1
        else:
            self.__key3 = des(key[16:], self._mode, self._iv,
                              self._padding, self._padmode)
        _baseDes.setKey(self, key)

    # 重写setter方法以处理所有3个键。

    def setMode(self, mode):
        # 设置加密模式的类型，DES.ECB 或者DES.CBC
        _baseDes.setMode(self, mode)
        for key in (self.__key1, self.__key2, self.__key3):
            key.setMode(mode)

    def setPadding(self, pad):
        # setPadding() -> 长度为1的字节. 填充字符
        _baseDes.setPadding(self, pad)
        for key in (self.__key1, self.__key2, self.__key3):
            key.setPadding(pad)

    def setPadMode(self, mode):
        # 设置填充模式的类型pyDes。 pyDes.PAD_NORMAL 或者 pyDes.PAD_PKCS5
        _baseDes.setPadMode(self, mode)
        for key in (self.__key1, self.__key2, self.__key3):
            key.setPadMode(mode)

    def setIV(self, IV):
        # 设置初始值, 与CBC模式一起使用
        _baseDes.setIV(self, IV)
        for key in (self.__key1, self.__key2, self.__key3):
            key.setIV(IV)

    def encrypt(self, data, pad=None, padmode=None):

        ENCRYPT = des.ENCRYPT
        DECRYPT = des.DECRYPT
        data = self._guardAgainstUnicode(data)
        if pad is not None:
            pad = self._guardAgainstUnicode(pad)
        # 相应的填充数据
        data = self._padData(data, pad, padmode)
        if self.getMode() == CBC:
            self.__key1.setIV(self.getIV())
            self.__key2.setIV(self.getIV())
            self.__key3.setIV(self.getIV())
            i = 0
            result = []
            while i < len(data):
                block = self.__key1.crypt(data[i:i + 8], ENCRYPT)
                block = self.__key2.crypt(block, DECRYPT)
                block = self.__key3.crypt(block, ENCRYPT)
                self.__key1.setIV(block)
                self.__key2.setIV(block)
                self.__key3.setIV(block)
                result.append(block)
                i += 8
            if _pythonMajorVersion < 3:
                return ''.join(result)
            else:
                return bytes.fromhex('').join(result)
        else:
            data = self.__key1.crypt(data, ENCRYPT)
            data = self.__key2.crypt(data, DECRYPT)
            return self.__key3.crypt(data, ENCRYPT)

    def decrypt(self, data, pad=None, padmode=None):

        ENCRYPT = des.ENCRYPT
        DECRYPT = des.DECRYPT
        data = self._guardAgainstUnicode(data)
        if pad is not None:
            pad = self._guardAgainstUnicode(pad)
        if self.getMode() == CBC:
            self.__key1.setIV(self.getIV())
            self.__key2.setIV(self.getIV())
            self.__key3.setIV(self.getIV())
            i = 0
            result = []
            while i < len(data):
                iv = data[i:i + 8]
                block = self.__key3.crypt(iv, DECRYPT)
                block = self.__key2.crypt(block, ENCRYPT)
                block = self.__key1.crypt(block, DECRYPT)
                self.__key1.setIV(iv)
                self.__key2.setIV(iv)
                self.__key3.setIV(iv)
                result.append(block)
                i += 8
            if _pythonMajorVersion < 3:
                data = ''.join(result)
            else:
                # fromhex可以用来对输入直接进行bytes化
                data = bytes.fromhex('').join(result)
        else:
            data = self.__key3.crypt(data, DECRYPT)
            data = self.__key2.crypt(data, ENCRYPT)
            data = self.__key1.crypt(data, DECRYPT)
        return self._unpadData(data, pad, padmode)
