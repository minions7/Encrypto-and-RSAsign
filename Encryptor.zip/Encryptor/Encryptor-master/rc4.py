# 初始化算法
# RC4其核心部分的S-box长度可为任意，但一般为256字节。该算法的速度可以达到DES加密的10倍左右。
def KSA(key):
    keylength = len(key)

    S = list(range(256))

# 初始排列状态向量S
    j = 0
    for i in range(256):
        j = (j + S[i] + key[i % keylength]) % 256
        S[i], S[j] = S[j], S[i]  # 交换

    return S


# 伪随机子密码生成算法
# 伪随机是机器通过函数随机生成的
def PRGA(S):
    i = 0
    j = 0
    while True:
        # 产生密钥流
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]  # 交换

        K = S[(S[i] + S[j]) % 256]
        # 上下文管理器yield 定义上面的K。
        yield K


def RC4(key):
    S = KSA(key)
    return PRGA(S)


if __name__ == '__main__':

    # 密文应为BBF316E8D940AF0AD3
    key = 'Key'
    plaintext = 'Plaintext'

    def convert_key(s):
        return [ord(c) for c in s]

    # 返回字节C的ASCII码
    key = [ord(c) for c in key]

    keystream = RC4(key)
    cipher = ''
    import sys

    for c in plaintext:
        # X表示以十六进制输出，02表示不足两位的前面补0输出
        # 一个字节一个字节的加密输出
        k = "%02X" % (ord(c) ^ keystream.__next__())
        cipher += k
    print(cipher)
